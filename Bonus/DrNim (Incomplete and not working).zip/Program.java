/**
 * Created by nate on 12/14/15.
 */
public class Program {
    public static void main(String[] args) {
        Game game = new Game();
    }

}
