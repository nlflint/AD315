/**
 * Created by nate on 12/14/15.
 */
public interface IPredicate {
    boolean isTrue(String symbol);
}
