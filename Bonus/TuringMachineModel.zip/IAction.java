/**
 * Created by nate on 12/14/15.
 */
public interface IAction {
    void Do(Tape tape);
}
