/**
 * Created by nate on 12/14/15.
 */
public class Left implements IAction {
    public void Do(Tape tape) {
        tape.Left();

    }
}
